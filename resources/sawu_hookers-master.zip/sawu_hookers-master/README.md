## This is the most ridiculous and useless thing i have ever made
There is a Pimp NPC at coords: x= 130.43, y= -1324.84, z= 28.21
There you can open a menu where you can select the hooker you want. rofl

From there you have to drive and pick up the hooker at the location marked on you GPS.

Do not reupload without my permission.

## Dependencies
- [Mythic Notifications](https://forum.fivem.net/t/dev-resource-mythic-notifications/587071)
Make sure you have the latest release of mythic_notify. I am using the new function to draw notifications in this script.

## Credits
The UI i used is based on a resource @Xander1988 and @darkzygb made, i cant remember what resource but i have to give them all the credits for it. 
[Permission from @Xander1988](https://gyazo.com/82d85ab00b0da45578c52f217aa55626)
 
